/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.act1;

/**
 *
 * @author PC104
 */
public class Act1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
